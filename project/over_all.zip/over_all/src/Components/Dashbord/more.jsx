import React from 'react';

const More = () => {
  return (
    <div>
      <h1>More</h1>
      {/* Add your content here */}
    </div>
  );
};

export default More;
